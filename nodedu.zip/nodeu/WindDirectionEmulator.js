var mqtt = require('mqtt');
const thingsboardHost = "demo.thingsboard.io";
const ACCESS_TOKEN = "Z61K03FAGSziW9b0nKsm";
const minDirection = 0,
    maxDirection = 359;
console.log('Connecting to: %s using access token: %s', thingsboardHost, ACCESS_TOKEN);
var client = mqtt.connect('mqtt://' + thingsboardHost, {
    username: ACCESS_TOKEN
});
var windDirection = minDirection + (maxDirection - minDirection) * Math.random();
client.on('connect', function() {
    console.log('Client connected!');
    console.log('Uploading  wind direction data once per second...');
    setInterval(publishTelemetry, 5000);
});

function publishTelemetry() {
    windDirection = genNextValue(windDirection, minDirection, maxDirection);
    console.log('Sending: ' + JSON.stringify({
        windDirection: windDirection
    }));
    client.publish('v1/devices/me/telemetry', JSON.stringify({
        windDirection: windDirection
    }));
}

function genNextValue(prevValue, min, max) {
    var value = prevValue + ((max - min) * (Math.random() - 0.5)) * 0.03;
    value = Math.max(min, Math.min(max, value));
    return Math.round(value * 10) / 10;
}
process.on('SIGINT', function() {
    console.log();
    console.log('Disconnecting...');
    client.end();
    console.log('Exited!');
    process.exit(2);
});
process.on('uncaughtException', function(e) {
    console.log('Uncaught Exception...');
    console.log(e.stack);
    process.exit(99);
});
